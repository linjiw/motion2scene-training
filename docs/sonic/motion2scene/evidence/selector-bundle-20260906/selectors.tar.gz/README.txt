Fixed Motion2Scene comparison selectors, September 6.
Architecture 214-64-32-2; training counts eleven encounters per arm.
Contains original twenty small selector checkpoints and exact training values.
SONIC, motion banks and simulator assets are not included.
Reproduce with the matching research source snapshot and CPU PyTorch:
PYTHONPATH=. python scripts/research/bundle_motion2scene_selectors.py verify --out <this-bundle-folder>
The verify command checks every parameter and normalization tensor bitwise; it performs no physics.
Reuse the original files for evaluation; verification fits are not additional primary models.
